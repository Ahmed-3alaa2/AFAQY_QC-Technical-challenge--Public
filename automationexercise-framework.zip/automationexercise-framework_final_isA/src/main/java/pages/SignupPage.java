package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Map;

public class SignupPage {

    WebDriver driver;

    public SignupPage(WebDriver driver) {
        this.driver = driver;
    }

    By name = By.name("name");
    By email = By.xpath("//input[@data-qa='signup-email']");
    By signupBtn = By.xpath("//button[@data-qa='signup-button']");

    By password = By.id("password");
    By firstName = By.id("first_name");
    By lastName = By.id("last_name");
    By address = By.id("address1");
    By state = By.id("state");
    By city = By.id("city");
    By zipcode = By.id("zipcode");
    By mobile = By.id("mobile_number");

    By createAccountBtn =
            By.xpath("//button[@data-qa='create-account']");

    By logoutBtn =
            By.xpath("//a[contains(text(),'Logout')]");

    public void enterSignupData(
            String userName,
            String userEmail) {

        driver.findElement(name).sendKeys(userName);
        driver.findElement(email).sendKeys(userEmail);

        driver.findElement(signupBtn).click();
    }

    public void fillRegistrationForm(
            Map<String, String> user) {

        driver.findElement(password)
                .sendKeys(user.get("password"));

        driver.findElement(firstName)
                .sendKeys(user.get("firstName"));

        driver.findElement(lastName)
                .sendKeys(user.get("lastName"));

        driver.findElement(address)
                .sendKeys(user.get("address"));

        driver.findElement(state)
                .sendKeys(user.get("state"));

        driver.findElement(city)
                .sendKeys(user.get("city"));

        driver.findElement(zipcode)
                .sendKeys(user.get("zipcode"));

        driver.findElement(mobile)
                .sendKeys(user.get("mobile"));

        driver.findElement(createAccountBtn)
                .click();
    }

    public void logout() {
        driver.findElement(logoutBtn).click();
    }
}
