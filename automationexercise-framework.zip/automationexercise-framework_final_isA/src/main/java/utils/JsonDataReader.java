package utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.util.List;
import java.util.Map;

public class JsonDataReader {

    public static List<Map<String, String>> getUserData() {

        try {

            ObjectMapper mapper = new ObjectMapper();

            return mapper.readValue(
                    new File("src/test/resources/users.json"),
                    new TypeReference<List<Map<String, String>>>() {}
            );

        } catch (Exception e) {

            throw new RuntimeException(e);
        }
    }
}
