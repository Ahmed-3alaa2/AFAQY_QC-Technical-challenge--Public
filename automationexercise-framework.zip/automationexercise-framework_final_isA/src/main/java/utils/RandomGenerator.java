package utils;

import java.util.UUID;

public class RandomGenerator {

    public static String generateEmail(String firstName) {

        return firstName.toLowerCase()
                + UUID.randomUUID()
                .toString()
                .substring(0,5)
                + "@mail.com";
    }
}
