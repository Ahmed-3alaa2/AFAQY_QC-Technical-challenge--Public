package tests;

import base.BaseTest;
import dataProviders.UserDataProvider;
import org.testng.annotations.Test;
import pages.AccountCreatedPage;
import pages.HomePage;
import pages.SignupPage;
import utils.RandomGenerator;

import java.util.Map;

public class SignupTest extends BaseTest {

    @Test(dataProvider = "signupData",
            dataProviderClass = UserDataProvider.class)

    public void signupTest(
            Map<String, String> userData) {

        HomePage homePage =
                new HomePage(driver);

        SignupPage signupPage =
                new SignupPage(driver);

        AccountCreatedPage accountPage =
                new AccountCreatedPage(driver);

        String email =
                RandomGenerator.generateEmail(
                        userData.get("firstName"));

        homePage.clickSignupLogin();

        signupPage.enterSignupData(
                userData.get("firstName"),
                email
        );

        signupPage.fillRegistrationForm(userData);

        accountPage.clickContinue();

        signupPage.logout();
    }
}
