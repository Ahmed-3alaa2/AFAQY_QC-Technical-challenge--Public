package dataProviders;

import org.testng.annotations.DataProvider;
import utils.JsonDataReader;

import java.util.List;
import java.util.Map;

public class UserDataProvider {

    @DataProvider(name = "signupData")
    public Object[][] signupData() {

        List<Map<String, String>> data =
                JsonDataReader.getUserData();

        Object[][] result =
                new Object[data.size()][1];

        for (int i = 0; i < data.size(); i++) {

            result[i][0] = data.get(i);
        }

        return result;
    }
}
